const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const crypto = require('crypto');
const { promisify } = require('util');

const scryptAsync = promisify(crypto.scrypt);

async function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const derivedKey = await scryptAsync(password, salt, 64);
  return `${salt}:${derivedKey.toString('hex')}`;
}

async function verifyPassword(password, storedPassword) {
  const [salt, keyHex] = String(storedPassword).split(':');
  if (!salt || !keyHex) return false;
  const derivedKey = await scryptAsync(password, salt, 64);
  const storedKey = Buffer.from(keyHex, 'hex');
  return storedKey.length === derivedKey.length && crypto.timingSafeEqual(storedKey, derivedKey);
}

const app = express();
const PORT = process.env.PORT || 5000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/lms';

app.use(cors());
app.use(express.json());

mongoose.connect(MONGO_URI)
  .then(() => console.log('MongoDB connected'))
  .catch((err) => console.error('MongoDB connection error:', err.message));

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String, required: true },
    role: { type: String, default: 'student' }
  },
  { timestamps: true }
);

const courseSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    category: { type: String, required: true, trim: true },
    youtubeLink: { type: String, required: true, trim: true }
  },
  { timestamps: true }
);

const User = mongoose.model('User', userSchema);
const Course = mongoose.model('Course', courseSchema);

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'smart-lms-backend' });
});

app.post('/api/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ msg: 'Name, email and password are required' });
    }

    const existingUser = await User.findOne({ email: email.toLowerCase() });
    if (existingUser) {
      return res.status(409).json({ msg: 'User already exists' });
    }

    const newUser = new User({
      name,
      email: email.toLowerCase(),
      passwordHash: await hashPassword(password)
    });

    await newUser.save();
    res.status(201).json({ msg: 'User registered successfully' });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ msg: 'Server error while registering user' });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ msg: 'Email and password are required' });
    }

    const user = await User.findOne({
      email: email.toLowerCase(),
      passwordHash: await hashPassword(password)
    });

    if (!user) {
      return res.status(401).json({ msg: 'Invalid credentials' });
    }

    res.json({
      msg: 'Login successful',
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role
      }
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ msg: 'Server error while logging in' });
  }
});

app.get('/api/courses', async (req, res) => {
  try {
    const courses = await Course.find().sort({ createdAt: -1 });
    res.json(courses);
  } catch (err) {
    console.error('Get courses error:', err);
    res.status(500).json({ msg: 'Server error while loading courses' });
  }
});

app.post('/api/courses', async (req, res) => {
  try {
    const { title, category, youtubeLink } = req.body;

    if (!title || !category || !youtubeLink) {
      return res.status(400).json({ msg: 'Title, category and YouTube link are required' });
    }

    const newCourse = new Course({ title, category, youtubeLink });
    await newCourse.save();

    res.status(201).json({ msg: 'Course added successfully', course: newCourse });
  } catch (err) {
    console.error('Add course error:', err);
    res.status(500).json({ msg: 'Server error while adding course' });
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
});
