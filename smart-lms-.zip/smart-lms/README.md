# Smart LMS

A full-stack Learning Management System with a Node.js/Express backend, MongoDB, static frontend, Docker support, and Kubernetes manifests.

## Project structure

```text
smart-lms/
├── backend/
│   ├── server.js
│   ├── package.json
│   ├── package-lock.json
│   └── Dockerfile
├── frontend/
│   ├── index.html
│   ├── login.html
│   ├── register.html
│   ├── dashboard.html
│   ├── courses.html
│   ├── admin.html
│   ├── student.html
│   ├── profile.html
│   ├── script.js
│   ├── style.css
│   ├── Dockerfile
│   └── nginx.conf
└── k8s/
    ├── backend-deploy.yaml
    ├── frontend-deploy.yaml
    └── mongo-deploy.yaml
```

## Backend

```bash
cd backend
npm ci
npm start
```

By default the backend uses `mongodb://127.0.0.1:27017/lms`.

For Kubernetes, `MONGO_URI` is set to `mongodb://mongo-service:27017/lms`.

## Kubernetes

1. Build and push the two Docker images.
2. Replace `YOUR_DOCKERHUB_USERNAME` in `k8s/backend-deploy.yaml` and `k8s/frontend-deploy.yaml`.
3. Apply the manifests:

```bash
kubectl apply -f k8s/mongo-deploy.yaml
kubectl apply -f k8s/backend-deploy.yaml
kubectl apply -f k8s/frontend-deploy.yaml
```

The frontend Nginx server proxies `/api/*` requests to the Kubernetes `backend-service`, so the browser does not need direct access to the internal backend service.

## Important note

This project is suitable as a learning/demo LMS. Passwords are hashed with Node.js scrypt in this demo. For production, add secure sessions/JWTs, stronger authorization controls, and persistent MongoDB storage with credentials.
