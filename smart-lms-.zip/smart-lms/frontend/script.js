const API_BASE = '/api';

async function registerUser(event) {
  if (event) event.preventDefault();

  const name = document.getElementById('name')?.value.trim();
  const email = document.getElementById('email')?.value.trim();
  const password = document.getElementById('password')?.value;

  if (!name || !email || !password) {
    alert('Please fill all required fields.');
    return false;
  }

  try {
    const res = await fetch(`${API_BASE}/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password })
    });

    const data = await res.json();
    alert(data.msg);

    if (res.ok) {
      window.location.href = 'login.html';
    }
  } catch (error) {
    console.error(error);
    alert('Unable to connect to the backend.');
  }

  return false;
}

async function loginUser(event) {
  if (event) event.preventDefault();

  const email = document.getElementById('email')?.value.trim();
  const password = document.getElementById('password')?.value;

  if (!email || !password) {
    alert('Please enter your email and password.');
    return false;
  }

  try {
    const res = await fetch(`${API_BASE}/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    const data = await res.json();

    if (res.ok) {
      alert(data.msg);
      localStorage.setItem('user', JSON.stringify(data.user));
      window.location.href = 'dashboard.html';
    } else {
      alert(data.msg);
    }
  } catch (error) {
    console.error(error);
    alert('Unable to connect to the backend.');
  }

  return false;
}
